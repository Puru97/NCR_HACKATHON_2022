from chatterbot import ChatBot
import chatterbot
#from chatterbot.trainers import ListTrainer
from chatterbot.trainers import ChatterBotCorpusTrainer
import chatterbot_corpus
from requests import request
import os
import pyttsx3 as pp
import speech_recognition as s
from flask import Flask, render_template, request, jsonify
from tkinter import *
from sqlalchemy import true

engine = pp.init()

voices = engine.getProperty('voices')

engine.setProperty('voice',voices[1].id)
engine.setProperty("Rate",178)
def speak(word):
    engine.say(word)
    #engine.runAndWait()

CURRENT_DIRECTORY = os.path.dirname(os.path.abspath(__file__))
DATA_DIRECTORY = os.path.join(CURRENT_DIRECTORY, 'data')
# Create a new chat bot named Charlie
chatbot = ChatBot('Narad',logic_adapters=[
        "chatterbot.logic.BestMatch",
        "chatterbot.logic.MathematicalEvaluation",
        "chatterbot.logic.BestMatch"],
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    database_uri='sqlite:///database.sqlite3')


#trainer = ListTrainer(chatbot)
#trainer.train("data")

corpus_trainer = ChatterBotCorpusTrainer(chatbot)
corpus_trainer.train("data\custom")
corpus_trainer.train("chatterbot.corpus.english")
    
app = Flask(__name__)    

@app.route('/')
def MainPage():
    return render_template("index.html")

@app.route("/get")
def get_bot_response():
    print("here")
    ##print("URL : ", request.GET.get('chat-input'))
    usertext = request.args.get('msg')
#  print("Hi Amit"+usertext)
    return str(chatbot.get_response(usertext))
    
# print(str(chatbot.get_response(usertext)))
if __name__ == "__main__":
    app.run(debug=true)
    # Press ctrl-c or ctrl-d on the keyboard to exit

